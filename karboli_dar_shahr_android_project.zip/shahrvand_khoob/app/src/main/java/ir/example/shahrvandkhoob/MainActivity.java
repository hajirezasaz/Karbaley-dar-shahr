package ir.example.shahrvandkhoob;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(245,241,232));
        getWindow().setNavigationBarColor(Color.rgb(245,241,232));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        setContentView(new GameView(this));
    }

    static class Stage {
        String title, question; String[] choices;
        int correct;
        String tip;
        Stage(String t,String q,String[] c,int a,String f){title=t;question=q;choices=c;correct=a;tip=f;}
    }

    static class GameView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap character;
        ArrayList<Stage> stages = new ArrayList<>();
        int screen=0, level=0, score=0, selected=-1;
        RectF[] choiceRects = new RectF[3];
        RectF startRect=new RectF(), nextRect=new RectF(), restartRect=new RectF();
        float den;

        int bg=Color.rgb(248,245,238), ink=Color.rgb(42,43,44), brown=Color.rgb(103,72,48);
        int paper=Color.rgb(255,252,246), green=Color.rgb(64,125,78), red=Color.rgb(175,67,58), gold=Color.rgb(207,151,53);

        GameView(Context c){
            super(c); den=getResources().getDisplayMetrics().density;
            character=BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("character","drawable",c.getPackageName()));
            buildStages(); setFocusable(true);
        }
        void buildStages(){
            stages.add(new Stage("مرحله ۱ | خیابان امن","چراغ عابر قرمز است و عجله داری. چه کار می‌کنی؟",
                new String[]{"از خط عابر رد می‌شوم و صبر می‌کنم","از بین خودروها رد می‌شوم","تا سبز شدن چراغ عابر صبر می‌کنم"},2,"قانون ساده: حتی وقتی عجله داریم، عبور ایمن و رعایت چراغ راهنمایی از حقوق خودمان و دیگران محافظت می‌کند."));
            stages.add(new Stage("مرحله ۲ | صف","در صف نانوایی چند نفر جلوتر از تو هستند و دوستت می‌گوید برو جلو. چه می‌کنی؟",
                new String[]{"جای دیگران را می‌گیرم","نوبتم را رعایت می‌کنم","دوستم را هم جلو می‌برم"},1,"رعایت نوبت یعنی احترام به زمان و حق دیگران؛ یک رفتار کوچک با اثر اجتماعی بزرگ."));
            stages.add(new Stage("مرحله ۳ | شهر تمیز","در پارک پوست خوراکی روی زمین افتاده و سطل نزدیک توست.",
                new String[]{"آن را داخل سطل می‌اندازم","کنارش رد می‌شوم","آن را زیر نیمکت پنهان می‌کنم"},0,"فضای عمومی متعلق به همه است. جمع‌کردن زباله و تفکیک درست، مسئولیت مشترک شهروندی است."));
            stages.add(new Stage("مرحله ۴ | اموال عمومی","می‌بینی روی نیمکت پارک نوشته‌ای با ماژیک کشیده شده است.",
                new String[]{"من هم چیزی اضافه می‌کنم","بی‌تفاوت می‌گذرم","از تخریب جلوگیری و موضوع را به مسئول مربوط اطلاع می‌دهم"},2,"اموال عمومی هزینه و استفاده مشترک دارند. مراقبت از آنها یعنی احترام به حق همه شهروندان."));
            stages.add(new Stage("مرحله ۵ | اتوبوس","اتوبوس شلوغ است و یک صندلی مخصوص فرد دارای معلولیت خالی مانده.",
                new String[]{"روی آن می‌نشینم و جا نمی‌دهم","اگر فردی که نیاز دارد آمد، صندلی را در اختیارش می‌گذارم","وسایلم را روی صندلی می‌گذارم"},1,"دسترسی برابر یعنی فضا و امکانات عمومی را با توجه به نیاز دیگران هم در نظر بگیریم."));
            stages.add(new Stage("مرحله ۶ | همسایه‌ها","ساعت دیر وقت است و می‌خواهی با صدای بلند بازی کنی.",
                new String[]{"صدا را کم می‌کنم","پنجره را باز می‌کنم تا صدا بیشتر شود","اهمیتی نمی‌دهم"},0,"آرامش همسایه‌ها بخشی از حق زندگی در فضای مشترک است؛ زمان و شدت صدا مهم است."));
            stages.add(new Stage("مرحله ۷ | فضای مجازی","یک پیام ناشناس از تو اطلاعات شخصی و رمز عبورت را می‌خواهد.",
                new String[]{"رمز را می‌فرستم","اطلاعات را نمی‌دهم و پیام را گزارش یا مسدود می‌کنم","برای دوست‌هایم هم می‌فرستم"},1,"در فضای مجازی هم شهروند مسئول هستیم: اطلاعات حساس را منتشر نکن و پیام مشکوک را گزارش کن."));
            stages.add(new Stage("مرحله ۸ | مصرف درست","در کلاس شیر آب باز مانده و کسی آنجا نیست.",
                new String[]{"شیر را می‌بندم و در صورت خرابی اطلاع می‌دهم","بی‌خیال می‌شوم","آب را بیشتر باز می‌کنم"},0,"منابع عمومی محدودند. صرفه‌جویی در آب و انرژی، مسئولیتی است که به همه کمک می‌کند."));
            stages.add(new Stage("مرحله ۹ | کمک به دیگران","فردی مسن کنار خیابان برای پیدا کردن مسیر دچار مشکل شده است.",
                new String[]{"مسخره‌اش می‌کنم","با احترام می‌پرسم آیا کمکی لازم دارد","بدون توجه رد می‌شوم"},1,"کمک داوطلبانه، محترمانه و بدون تحقیر، یکی از پایه‌های همدلی و مشارکت اجتماعی است."));
            stages.add(new Stage("مرحله ۱۰ | شهر بهتر","می‌بینی چراغی در فضای عمومی خراب شده و شب‌ها خطر ایجاد می‌کند.",
                new String[]{"نادیده می‌گیرم","خودم با ابزار نامناسب تعمیرش می‌کنم","موضوع را از مسیر رسمی به مسئول مربوط گزارش می‌کنم"},2,"مشارکت مسئولانه یعنی مشکل را از مسیر درست گزارش کنیم و جان خود و دیگران را به خطر نیندازیم."));
        }

        float d(float x){return x*den;}
        void rect(Canvas c,int color,float l,float t,float r,float b,float rad){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(l,t,r,b),rad,rad,p);}
        void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align align,boolean bold){
            p.setColor(color);p.setTextSize(d(size));p.setTextAlign(align);p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));p.setStyle(Paint.Style.FILL);
            c.drawText(s,x,y,p);
        }
        void multiline(Canvas c,String s,float x,float y,float size,int color,float maxWidth,boolean bold){
            p.setTextSize(d(size));p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));
            String[] words=s.split(" "); String line=""; float yy=y;
            for(String w:words){ String test=line.length()==0?w:line+" "+w; if(p.measureText(test)>d(maxWidth) && line.length()>0){text(c,line,x,yy,size,color,Paint.Align.RIGHT,bold);yy+=d(size+9);line=w;} else line=test; }
            if(line.length()>0) text(c,line,x,yy,size,color,Paint.Align.RIGHT,bold);
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c); c.drawColor(bg);
            if(screen==0) drawHome(c); else if(screen==1) drawQuestion(c); else if(screen==2) drawFeedback(c); else drawResult(c);
        }
        void drawHeader(Canvas c,String title){
            text(c,"کربلی در شهر",getWidth()-d(24),d(42),24,ink,Paint.Align.RIGHT,true);
            text(c,title,d(24),d(40),14,brown,Paint.Align.LEFT,false);
            p.setStrokeWidth(d(1));p.setColor(Color.rgb(220,213,200));c.drawLine(d(24),d(58),getWidth()-d(24),d(58),p);
        }
        void drawHome(Canvas c){
            drawHeader(c,"کربلی در شهر");
            // character
            Rect src=new Rect(0,0,character.getWidth(),character.getHeight());
            float cw=Math.min(getWidth()*0.52f,d(250)), ch=cw*character.getHeight()/character.getWidth();
            RectF dst=new RectF(d(18),d(82),d(18)+cw,d(82)+ch); c.drawBitmap(character,src,dst,p);
            text(c,"۱۰ مأموریت برای",getWidth()-d(28),d(135),25,ink,Paint.Align.RIGHT,true);
            text(c,"یک شهر بهتر",getWidth()-d(28),d(172),25,green,Paint.Align.RIGHT,true);
            multiline(c,"در هر مرحله یک موقعیت واقعی را ببین و با انتخاب درست، امتیاز بگیر.",getWidth()-d(28),d(220),16,ink,d(220),false);
            text(c,"مناسب ۱۰ تا ۲۰ سال",getWidth()-d(28),d(315),14,brown,Paint.Align.RIGHT,true);
            text(c,"بدون نیاز به اینترنت • بدون تبلیغ",getWidth()-d(28),d(345),13,Color.DKGRAY,Paint.Align.RIGHT,false);
            startRect.set(getWidth()-d(245),d(390),getWidth()-d(28),d(452));
            rect(c,green,startRect.left,startRect.top,startRect.right,startRect.bottom,d(18));
            text(c,"شروع بازی",startRect.centerX(),startRect.centerY()+d(8),19,Color.WHITE,Paint.Align.CENTER,true);
            text(c,"قوانین را بخوان، انتخاب کن، یاد بگیر.",getWidth()-d(28),d(495),13,Color.GRAY,Paint.Align.RIGHT,false);
        }
        void drawQuestion(Canvas c){
            Stage s=stages.get(level); drawHeader(c,"مرحله "+(level+1)+" از ۱۰");
            float w=getWidth()-d(48);
            rect(c,paper,d(24),d(80),getWidth()-d(24),d(275),d(18));
            text(c,s.title,getWidth()-d(42),d(112),19,brown,Paint.Align.RIGHT,true);
            multiline(c,s.question,getWidth()-d(42),d(155),18,ink,w-36,false);
            // progress
            rect(c,Color.rgb(226,220,209),d(24),d(292),getWidth()-d(24),d(301),d(5));
            rect(c,green,d(24),d(292),d(24)+w*((level+1)/10f),d(301),d(5));
            for(int i=0;i<3;i++){
                float top=d(325+i*82); choiceRects[i]=new RectF(d(24),top,getWidth()-d(24),top+d(64));
                int col=(selected==i)?(i==s.correct?green:red):paper;
                rect(c,col,choiceRects[i].left,choiceRects[i].top,choiceRects[i].right,choiceRects[i].bottom,d(16));
                int tc=(selected==i)?Color.WHITE:ink;
                text(c,(i+1)+".",d(47),top+d(40),16,tc,Paint.Align.LEFT,true);
                multiline(c,s.choices[i],getWidth()-d(52),top+d(39),15,tc,w-55,false);
            }
        }
        void drawFeedback(Canvas c){
            Stage s=stages.get(level); drawHeader(c,"نتیجه انتخاب");
            boolean ok=selected==s.correct;
            text(c,ok?"آفرین! انتخاب مسئولانه":"این انتخاب بهتر است اصلاح شود",getWidth()-d(28),d(120),23,ok?green:red,Paint.Align.RIGHT,true);
            text(c,ok?"+۱۰ امتیاز":"+۰ امتیاز",getWidth()-d(28),d(155),16,ink,Paint.Align.RIGHT,true);
            rect(c,paper,d(24),d(190),getWidth()-d(24),d(430),d(18));
            text(c,"نکته شهروندی",getWidth()-d(45),d(230),17,brown,Paint.Align.RIGHT,true);
            multiline(c,s.tip,getWidth()-d(45),d(270),17,ink,getWidth()/den-90,false);
            text(c,"امتیاز: "+score,getWidth()-d(28),d(475),16,green,Paint.Align.RIGHT,true);
            nextRect.set(d(24),d(510),getWidth()-d(24),d(574));
            rect(c,green,nextRect.left,nextRect.top,nextRect.right,nextRect.bottom,d(18));
            text(c,level==9?"مشاهده نتیجه نهایی":"مرحله بعد",nextRect.centerX(),nextRect.centerY()+d(7),18,Color.WHITE,Paint.Align.CENTER,true);
        }
        void drawResult(Canvas c){
            drawHeader(c,"پایان بازی");
            float center=getWidth()/2f;
            text(c,"تبریک!",center,d(145),30,gold,Paint.Align.CENTER,true);
            text(c,"تو ۱۰ مأموریت شهروندی را کامل کردی.",center,d(190),18,ink,Paint.Align.CENTER,false);
            text(c,"امتیاز نهایی",center,d(255),16,brown,Paint.Align.CENTER,true);
            text(c,score+" از ۱۰۰",center,d(310),42,green,Paint.Align.CENTER,true);
            String msg=score>=80?"مهارت‌های شهروندی‌ات را در زندگی روزمره هم تمرین کن.":"اشتباه‌ها هم فرصت یادگیری‌اند؛ دوباره بازی کن و نکته‌ها را مرور کن.";
            multiline(c,msg,getWidth()-d(28),d(370),17,ink,getWidth()/den-56,false);
            restartRect.set(d(24),d(460),getWidth()-d(24),d(524));
            rect(c,brown,restartRect.left,restartRect.top,restartRect.right,restartRect.bottom,d(18));
            text(c,"بازی دوباره",restartRect.centerX(),restartRect.centerY()+d(7),18,Color.WHITE,Paint.Align.CENTER,true);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP)return true; float x=e.getX(),y=e.getY();
            if(screen==0 && startRect.contains(x,y)){screen=1;invalidate();return true;}
            if(screen==1 && selected<0){
                for(int i=0;i<3;i++) if(choiceRects[i]!=null && choiceRects[i].contains(x,y)){selected=i; if(i==stages.get(level).correct)score+=10; screen=2;invalidate();return true;}
            } else if(screen==2 && nextRect.contains(x,y)){ if(level<9){level++;selected=-1;screen=1;}else screen=3;invalidate();return true; }
            else if(screen==3 && restartRect.contains(x,y)){level=0;selected=-1;score=0;screen=1;invalidate();return true;}
            return true;
        }
    }
}
